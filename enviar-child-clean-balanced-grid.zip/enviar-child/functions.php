<?php
/**
 * Enviar Child Blocksy bootstrap.
 *
 * Blocksy controls the site shell and Elementor controls page content.
 *
 * @package EnviarChildBlocksy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Load the parent and child theme styles without changing Elementor output.
 */
function enviar_child_blocksy_enqueue_styles(): void {
	$parent_theme = wp_get_theme( 'blocksy' );
	$child_css     = get_stylesheet_directory() . '/style.css';

	wp_enqueue_style(
		'blocksy-parent-style',
		get_template_directory_uri() . '/style.css',
		array(),
		$parent_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'enviar-child-blocksy-style',
		get_stylesheet_uri(),
		array( 'blocksy-parent-style' ),
		file_exists( $child_css ) ? (string) filemtime( $child_css ) : null
	);
}
add_action( 'wp_enqueue_scripts', 'enviar_child_blocksy_enqueue_styles', 20 );
